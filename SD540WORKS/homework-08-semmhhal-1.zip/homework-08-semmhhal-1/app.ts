import express, { NextFunction,Response,Request } from 'express'
import morgan from 'morgan'
import 'dotenv/config'
import userRouter from './users/routes'


const app=express()

//middlewares
app.use(morgan('dev'))
app.use('/studentcourses',userRouter) //the route became a middleware

//error handlers
app.use((error: Error, req: Request, res: Response, next: NextFunction) => {
    res.status(500).json({ sucess: false, msg: error.message })
})

app.listen(3000, () => console.log(`listening to 3000`))