import { RequestHandler } from "express"
import { StandardResponse } from "../types/response"
import { Student } from "./model"

export const get_Students:RequestHandler<unknown, StandardResponse<Student[]>, unknown, unknown>=async(req,res,next)=>{
    try{

    }
    catch(error){
        next(error)
    }
}

export const post_Students:RequestHandler<unknown,StandardResponse<Student[]>, unknown, unknown>=async(req,res,next)=>{
    try{

    }
    catch(error){
        next(error)
    }
}

export const get_Student:RequestHandler<unknown, StandardResponse<Student>, unknown, unknown>=async(req,res,next)=>{
    try{

    }
    catch(error){
        next(error)
    }
}


export const delete_Student:RequestHandler<unknown, StandardResponse<boolean>, unknown, unknown>=async(req,res,next)=>{
    try{

    }
    catch(error){
        next(error)
    }
}

export const put_Student:RequestHandler<unknown,StandardResponse<boolean>, unknown, unknown>=async(req,res,next)=>{
    try{

    }
    catch(error){
        next(error)
    }
}


