import { Schema,InferSchemaType,model } from "mongoose";


const CourseSchema = new Schema({
    code: { type: String, required: true },
    name: { type: String, required: true },
    description: String,
    deleted: { type: Boolean, default: false }
}, { timestamps: true });

const StudentSchema = new Schema({
    email: { type: String, required: true },
    name: { type: String, required: true },
    courses: [CourseSchema],
    deleted: { type: Boolean, default: false }
}, { timestamps: true });


export type Course= InferSchemaType<typeof CourseSchema>
export type Student= InferSchemaType<typeof StudentSchema>

export const StudentModel=model<Student>('student', StudentSchema)
