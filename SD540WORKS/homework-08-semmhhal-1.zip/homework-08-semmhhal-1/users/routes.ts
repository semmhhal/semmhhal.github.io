import express from 'express'
import {get_Students, post_Students, put_Student, delete_Student, get_Student } from './controllers'
import coursesRouter from './courses/routes'
const userRouter = express.Router() //built- in middleware



userRouter.get('/',get_Students)
userRouter.post('/',post_Students)
userRouter.get('/:', get_Student)
userRouter.put('/:', put_Student)
userRouter.delete('/:', delete_Student)

userRouter.use('/:course_code',coursesRouter)
export default userRouter