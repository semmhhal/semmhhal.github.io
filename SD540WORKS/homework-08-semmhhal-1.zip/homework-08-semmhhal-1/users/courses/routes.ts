import express from 'express'
import { delete_course, get_course, get_courses, post_courses, put_course } from './controllers2'
const coursesRouter= express.Router()

coursesRouter.get('/',get_courses)
coursesRouter.post('/',post_courses)
coursesRouter.get('/:course_code',get_course)
coursesRouter.put('/:course_code',put_course)
coursesRouter.delete('/:course_code',delete_course)

export default coursesRouter