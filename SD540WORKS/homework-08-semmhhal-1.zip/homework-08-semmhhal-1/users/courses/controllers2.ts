import { RequestHandler } from "express"
import { StandardResponse } from "../../types/response"
import { Course } from "../model"

export const get_courses:RequestHandler<unknown, StandardResponse<Course[]>, unknown, unknown>=async(req,res,next)=>{
    try{

    }
    catch(error){
        next(error)
    }
}

export const post_courses:RequestHandler<unknown,StandardResponse<Course[]>, unknown, unknown>=async(req,res,next)=>{
    try{

    }
    catch(error){
        next(error)
    }
}

export const get_course:RequestHandler<unknown, StandardResponse<Course>, unknown, unknown>=async(req,res,next)=>{
    try{

    }
    catch(error){
        next(error)
    }
}


export const delete_course:RequestHandler<unknown, StandardResponse<boolean>, unknown, unknown>=async(req,res,next)=>{
    try{

    }
    catch(error){
        next(error)
    }
}

export const put_course:RequestHandler<unknown,StandardResponse<boolean>, unknown, unknown>=async(req,res,next)=>{
    try{

    }
    catch(error){
        next(error)
    }
}


