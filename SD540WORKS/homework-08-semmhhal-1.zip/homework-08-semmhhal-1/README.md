[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/0rYiLkI2)
### SD540-REST
Given the following Mongoose Schema:
```typescript
const CourseSchema = new Schema({
    code: { type: String, required: true },
    name: { type: String, required: true },
    description: String,
    deleted: { type: Boolean, default: false }
}, { timestamps: true });

const StudentSchema = new Schema({
    email: { type: String, required: true },
    name: { type: String, required: true },
    courses: [CourseSchema],
    deleted: { type: Boolean, default: false }
}, { timestamps: true });
```
Create a Rest API which allows users to perform CRUD operations on `students` and `courses` entities.
