export interface StandardResponse<T>{
    sucess:boolean,
    data:T
}