import mongoose from 'mongoose'
import 'dotenv/config'


export function connectDB() {
    if (process.env.MONGODB_URL)
        mongoose.connect(process.env.MONGODB_URL)
            .then(() => console.log('connected sucessfully'))
            .catch(error => console.error(error))
}