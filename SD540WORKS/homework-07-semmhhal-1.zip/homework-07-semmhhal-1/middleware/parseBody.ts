import express from 'express'

export function parseBody() {
    return express.json()
}