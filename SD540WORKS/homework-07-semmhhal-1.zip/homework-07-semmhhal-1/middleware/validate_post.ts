import { RequestHandler } from 'express'
import { Contains, validate } from 'class-validator'
import { Newsletter } from '../models/model'

class ValidationRules {
    @Contains('weekly')
    interval: string = ''
}



//type1= request params
//type 2= response body
//type 3= request ody
//type 4= request query params

export const validate_post: RequestHandler<unknown, unknown, Newsletter, unknown> = async (req, res, next) => {
    const rules = new ValidationRules()
    rules.interval = req.body.interval;
    const errors = await validate(rules);
    if (errors.length > 0) {
        next(new Error(errors.toString()))
    } else {
        next()
    }
}