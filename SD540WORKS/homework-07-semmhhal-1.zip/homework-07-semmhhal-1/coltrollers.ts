import { Request, Response, NextFunction, RequestHandler } from 'express'
import { Newsletter, NewsletterModel } from "./models/model"

export const handleAll: RequestHandler<unknown, unknown, unknown, unknown> = (req, res, next) => {
    next(new Error('Route not found'))
}

export const ErrorHandler = (error: Error, req: Request, res: Response, next: NextFunction) => {
    res.json({ sucess: false, message: error.message })
}

export const post_newsletter_handler: RequestHandler<unknown, { sucess: boolean, _id: string; }, Newsletter, unknown> = async (req, res, next) => {
    try {
        const results = await NewsletterModel.create(req.body)
        res.json({ sucess: true, _id: results._id.toString() })
    }
    catch (error) {
        next(error)
    }
}

export const getUserEmails: RequestHandler<unknown, Newsletter[], unknown, unknown> = async (req, res, next) => {
    try {
        const allEmails = await NewsletterModel.find({ "subscription_status": true }, { "user.email": 1, "_id": 0 })
        res.json(allEmails)
    }
    catch (error) {
        next(error)
    }
}

//prof soln
//export const get_newsletter:RequestHandler<unknwon, {sucess:boolean, data:newsLetter},unknown,{projection:string;page?:string}>= async(req,res,next)=>{
   // try{
   // const Page_Size=10
   // let page=1
   // if(req.query.page){
     //   page=+req.query.page
    //}
    //cosnt {projection:requested_projection}=req.query
    //const query_projection"{[key:string]:number}={}
    //const requested_projection_array= requested_projection_string?.split(',')
    //requested_projection_array.forEach(Projection_field:string)=>{
       // query_projection['user.'+projection_field]=1 // {user.email:1, user.fullname:1}
   // }
    /// const results= await NewsletterModel.find(
           // {subscription status:true},{user.email:1})
          // .skip((page-1)*page_size)
           //.limit(page_size)
         //   results.json({sucess:true,data:results})
       // )
   // }
 //  catch(error){
   // next(error)
   //}
//}

export const getUsersByID: RequestHandler<{ user_id: string }, Newsletter, unknown, unknown> = async (req, res: Response, next) => {
    const findUser = await NewsletterModel.findOne({ "user._id": req.params.user_id });
   res.json(

        {
            interval: findUser?.interval,
            subscription_status: findUser?.subscription_status,
            user: {
                _id: findUser?.id,
                email: findUser?.user?.email,
                fullname: findUser?.user?.fullname,
            }
        })
    

}
//according to prof 
//get /newsletter/newsletter_id 
export const get_newsletter:RequestHandler<{newsletter_id:string},{sucess:boolean,data:Newsletter},unknown,unknown>= async (req,res,next)=>{
    try{
        const {newsletter_id}=req.params
        const results= await NewsletterModel.findOne({_id:newsletter_id })
        if(results)
        res.json({sucess:true,data:results?results:{} as Newsletter})
    }
    catch(error){
    next(error)
    }
}





//put/newsletter/:newsletter_id/?change=interval
//according to prof
export const put_newsletter:RequestHandler<{newsletter_id:string},{sucess:boolean,data:boolean},Newsletter,{change:string}>= async(req,res,next)=>{
    try{
            const{newsletter_id}=req.params
            const {change}=req.query
            const update_query:Record<string,any>={}
            //if change if passed, only change that field
            //otherwise, update the entire document
            if(change){
                update_query['$set']={[change]:req.body[change]}; //{$set:{interval:req.body.interval}}

            }
            else{

            }
            const results=await NewsletterModel.updateOne({_id:newsletter_id})
            res.json({sucess:true, data:true})
}catch(error){
next(error)}
}

export const updateInterval:RequestHandler<{user_id:string},Newsletter,{interval:'daily'},unknown>= async (req,res:Response, next)=>{
const updateUser= await NewsletterModel.updateOne({ "user._id": req.params.user_id },{"interval":req.body.interval})
const updateUser1= await NewsletterModel.findOne({ "user._id": req.params.user_id })
res.json({
    interval: updateUser1?.interval,
    subscription_status: updateUser1?.subscription_status,
    user: {
        _id: updateUser1?.id,
        email:updateUser1?.user?.email,
        fullname: updateUser1?.user?.fullname,
    }
})

}


//prof soln
//coming soon. 


export const changeSubscriptionStatus:RequestHandler<{user_id:string},Newsletter,{subscription_status:false},unknown>= async (req,res:Response, next)=>{
    const changedSS= await NewsletterModel.updateOne({ "user._id": req.params.user_id },{"interval":req.body.subscription_status})
    const changed2SS= await NewsletterModel.findOne({ "user._id": req.params.user_id })
    res.json({
        interval:changed2SS?.interval,
        subscription_status: changed2SS?.subscription_status,
        user: {
            _id: changed2SS?.id,
            email:changed2SS?.user?.email,
            fullname: changed2SS?.user?.fullname,
        }
    })
    

}
