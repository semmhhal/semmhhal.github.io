import express from 'express'
import morgan from 'morgan'
import 'dotenv/config'
import { handleAll, ErrorHandler, post_newsletter_handler, getUserEmails,getUsersByID, updateInterval, changeSubscriptionStatus } from './coltrollers'
import { connectDB } from './db_connect'
import { parseBody } from './middleware/parseBody'
import { validate_post } from './middleware/validate_post'

const app = express()

connectDB()
//morgain is a middleware that logs out everything that comes at the serverside 
app.use(morgan('dev'))


app.post('/newsletter', parseBody(), validate_post, post_newsletter_handler)
app.get('/newsletter', parseBody(), getUserEmails)
app.get('/newsletter', parseBody(), getUsersByID)
app.put('/newsletter',parseBody(),updateInterval)
app.delete('/newsletter',parseBody(),changeSubscriptionStatus)







//catch app route
app.all('*', handleAll)
app.use(ErrorHandler)



app.listen(3000, () => console.log('server is running on port 3000'))