import { model, InferSchemaType, Schema } from 'mongoose'


interface User {
    _id: Schema.Types.ObjectId;
    email: string;
    fullname: string;
}

export interface Newsletter extends Document {
    interval: string;
    subscription_status: boolean;
    user: User | null; 
}

export const NewsletterSchema = new Schema({
    interval: { type: String, enum: ['daily', 'weekly', 'monthly'], required: true },
    user: {
        _id: { type: Schema.Types.ObjectId, required: true },
        email: { type: String, required: true },
        fullname: { type: String, required: true }
    },
    subscription_status: { type: Boolean, default: true }
}, { timestamps: true });


// export type Newsletter = InferSchemaType<typeof NewsletterSchema>

export const NewsletterModel = model<Newsletter>('newsletter', NewsletterSchema)
